SAPFIRE — PRESS KIT
https://sapfire.app

ONE LINE
Sapfire is a free, open-source Mac browser with an Arc-style sidebar, built on Safari's engine, that installs extensions from the Chrome Web Store.

SHORT (50 words)
Sapfire is a light browser for Mac. Spaces with vertical tabs, split view up to four pages, Peek previews and an ad blocker that works on YouTube too. It runs on WebKit, the engine already in macOS, so it is 18 MB on disk. No account, no telemetry. Free and open source.

LONG
Sapfire keeps the way of working people loved in Arc: spaces with their own sign-ins, pinned and temporary tabs, folders, split view with up to four pages, Peek previews, a Little Window for links from other apps and a mini player in the sidebar. Arc users can bring everything over in one step: spaces, pinned tabs, folders, splits, history and passwords.

Under the hood it is a native Mac app on WebKit, the engine Safari uses. It does not ship its own copy of Chromium, so the app is 18 MB on disk and uses 77 MB of memory with an empty tab (Safari: 199 MB). It installs most extensions from the Chrome Web Store and Firefox Add-ons through Safari's engine.

Privacy is the default, not a setting: ads and trackers are blocked out of the box, there is no account and no telemetry, and Sapfire makes no network connections in the first 90 seconds after launch. Incognito goes only through your proxy, writes nothing to disk and locks with Touch ID.

Sapfire is free and open source under GPL-3.0.

FACTS
Version        1.0.1, released 16 November 2026 (1.0: 8 November 2026)
Price          Free
License        GPL-3.0 — https://github.com/sapfireapp/sapfire
Platform       macOS 14 or later (extensions: macOS 15.4 or later), Apple silicon and Intel
Download       8 MB DMG, signed with Developer ID and notarized by Apple
Engine         WebKit (the engine in Safari)
Import         From Arc: spaces, pinned tabs, folders, splits, history, passwords

NUMBERS
Sapfire 1.0 and Safari 27, MacBook Pro M3 Max, macOS 27, idle Mac, clean profile, 9 November 2026.
On disk                      18 MB (Helium 343 MB, Brave 878 MB)
Memory, empty tab, after 60 s  77 MB (Safari 199 MB), all processes of the app
Connections at launch        0 in the first 90 s (Safari: 2 servers)
Speedometer 3                45.3 (Safari 40.6) — 11% faster, same engine, less on top

FILES
sapfire-icon-1024.png          App icon, 1024 × 1024, transparent
sapfire-gem-512.png            The gem alone, 512 × 512, transparent
sapfire-screenshot.png         Sidebar with spaces, pinned sites and folders, 2800 × 1800
sapfire-banner-1200x630.png    Social banner

CONTACT
hello@sapfire.app
